
function pmpn(){
var pmpArray = ["The Poor Man's Polymath", "Dunnning-Kruger in Action!"];
var pmp=Math.round(Math.random(pmpArray.length));
    document.getElementById('pmp').innerHTML = (pmpArray[pmp]);}
pmpn();
